/* Item content and prices shared by the browser and authoritative economy server. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.NYTHRAVEL_CATALOGUE=api;})(globalThis,()=>{
 const merchant={x:1980,y:1030,range:135,safeRadius:110};
 const rows=[
 ['steel-sword','Стальной клинок','weapon',0,75,18,{dm:.035},'Меч ремесленника. Надёжен в ближнем бою.',0],
 ['moon-sword','Лунная сталь','weapon',2,420,100,{dm:.10,hp:8},'Клинок, закалённый в лунном свете.',0],
 ['shade-dagger','Кинжал сумрака','weapon',1,160,38,{dm:.035,sp:.02},'Лёгкий клинок для подвижного бойца.',0],
 ['wood-axe','Топор поселенца','weapon',0,65,15,{dm:.025},'И оружие, и инструмент для заготовки дерева.',3],
 ['rift-axe','Топор разлома','weapon',3,980,240,{dm:.14,hp:15},'Тяжёлая кристаллическая секира.',3],
 ['ash-bow','Ясеневый лук','weapon',0,75,18,{dm:.03},'Гибкое дерево и крепкая тетива.',1],
 ['wind-bow','Лук ветров','weapon',2,430,105,{dm:.08,sp:.025},'Тихий выстрел на границе леса.',1],
 ['apprentice-staff','Посох ученика','weapon',0,75,18,{dm:.03},'Простой фокус для магических сфер.',2],
 ['amethyst-staff','Аметистовый посох','weapon',3,1050,260,{dm:.14},'Резонатор фиолетового кристалла.',2],
 ['traveler-helm','Шлем путника','helm',0,60,14,{hp:12},'Защита для первых путешествий.'],
 ['warden-helm','Шлем дозорного','helm',1,180,43,{hp:22},'Знак стражи северной дороги.'],
 ['crystal-crown','Кристальный венец','helm',3,920,225,{hp:42,dm:.025},'Серебряная оправа удерживает свет кристалла.'],
 ['linen-vest','Походный нагрудник','armor',0,65,15,{ar:.035},'Плотная ткань и кожаные накладки.'],
 ['guard-mail','Кольчуга стражи','armor',1,210,50,{ar:.065},'Кольца смягчают физические удары.'],
 ['night-plate','Латы ночного дозора','armor',2,520,125,{ar:.105,hp:10},'Усиленная защита без тяжёлой поступи.'],
 ['work-gloves','Перчатки мастера','gloves',0,55,13,{dm:.02},'Крепкий хват оружия и инструмента.'],
 ['duelist-gloves','Перчатки дуэлянта','gloves',1,185,44,{dm:.04},'Тонкие пластины защищают руки.'],
 ['star-gloves','Звёздные рукавицы','gloves',3,900,220,{dm:.08,hp:8},'В швах мерцает осколочная пыль.'],
 ['road-boots','Сапоги дорог','boots',0,60,14,{sp:.025},'Надёжная подошва для дальнего пути.'],
 ['scout-boots','Сапоги разведчика','boots',1,190,45,{sp:.045},'Мягкая кожа не мешает движению.'],
 ['mist-boots','Поступь тумана','boots',2,490,118,{sp:.07},'Лёгкая поступь сквозь холодный туман.'],
 ['copper-ring','Медное кольцо','ring',0,70,16,{vp:.006},'Слабый отголосок жизненной магии.'],
 ['garnet-ring','Гранатовое кольцо','ring',1,220,52,{vp:.012},'Тёплый камень отвечает на удары.'],
 ['eclipse-ring','Кольцо затмения','ring',3,1100,270,{vp:.025,dm:.025},'Редкий круг из тёмного серебра.'],
 ['blue-amulet','Синий оберег','amu',0,75,18,{dm:.025},'Маленький кристалл направляет силу.'],
 ['silver-amulet','Серебряная печать','amu',2,510,122,{dm:.07,hp:10},'Печать мастеров разрушенной цитадели.'],
 ['path-talisman','Талисман пути','talisman',0,70,16,{sp:.015,hp:6},'Помнит каждый пройденный перекрёсток.'],
 ['dawn-talisman','Талисман рассвета','talisman',2,540,130,{hp:24,ar:.025},'Тёплый свет среди ночных руин.'],
 ['health-vial','Малое зелье жизни','consumable',0,24,5,{},'Восстанавливает 30% максимального HP.',null,null,{type:'heal',amount:.30}],
 ['health-flask','Большое зелье жизни','consumable',1,60,14,{},'Восстанавливает 55% максимального HP.',null,null,{type:'heal',amount:.55}],
 ['stamina-vial','Настой бодрости','consumable',0,22,5,{},'Восстанавливает 45 выносливости.',null,null,{type:'stamina',amount:45}],
 ['rage-draught','Настой ярости','consumable',1,45,10,{},'Усиление урона на 45 секунд.',null,null,{type:'buff',key:'dm',duration:45}],
 ['wind-draught','Настой ветра','consumable',1,40,9,{},'Ускорение на 45 секунд.',null,null,{type:'buff',key:'sp',duration:45}],
 ['wisdom-draught','Настой мудрости','consumable',2,70,16,{},'Двойной опыт на 45 секунд.',null,null,{type:'buff',key:'xp',duration:45}],
 ['champion-blade','Клятва чемпиона','weapon',3,1450,350,{dm:.16,hp:12},'Классовый меч хранителя переднего ряда.',0,0],
 ['forest-oath','Обет леса','weapon',3,1450,350,{dm:.13,sp:.025},'Классовый лук следопыта.',1,1],
 ['astral-staff','Астральный фокус','weapon',4,2800,680,{dm:.20,hp:12},'Классовый посох с сердцем звёздного кристалла.',2,2],
 ['mercy-sigil','Печать милосердия','talisman',3,1400,340,{hp:32,dm:.035},'Классовый знак хранителя жизни.',null,3],
 ['bastion-sigil','Печать бастиона','talisman',4,2800,680,{hp:48,ar:.065},'Классовый знак несокрушимой защиты.',null,4]
 ];
 const icons={weapon:'⚔',helm:'♙',armor:'♜',gloves:'✦',boots:'➶',ring:'◉',amu:'◇',talisman:'❖',consumable:'⚗'};
 const items=rows.map(([id,n,s,r,buy,sell,stats,description,weapon,cls,effect])=>({id,n,s,r,buy,sell,...stats,description,icon:icons[s],...(weapon!==null&&weapon!==undefined?{weapon}:{}),...(cls!==null&&cls!==undefined?{class:cls,minLevel:4}:{}),...(effect?{effect}:{}),t:r>=3?3:r>=2?2:1}));
 function find(id){return items.find(i=>i.id===id);}
 function make(id){const item=find(id);if(!item)return null;const {id:catalogId,buy,...rest}=item;return {catalogId,...rest};}
 function sellPrice(item){return item.catalogId?find(item.catalogId)?.sell||0:Math.max(1,Math.round(12*(1+(item.r||0)*.7)));}
 function canUse(item,context){return (item.class===undefined||item.class===(context.cl||0))&&(!item.minLevel||(context.lvl||1)>=item.minLevel);}
 return {items,merchant,find,make,sellPrice,canUse};
});
