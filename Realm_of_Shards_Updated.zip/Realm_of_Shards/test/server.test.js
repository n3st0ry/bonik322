const {test}=require('node:test');
const assert=require('node:assert/strict');
const WebSocket=require('ws');
const {createGameServer}=require('../server');
test('HTTP files, isolated lobbies, three players, host start, deduplication and disconnect',async()=>{
 const {server,wss}=createGameServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port,clients=[];
 const connect=()=>new Promise(resolve=>{const ws=new WebSocket(`ws://127.0.0.1:${port}`);clients.push(ws);ws.messages=[];ws.on('message',raw=>ws.messages.push(JSON.parse(raw)));ws.on('open',()=>resolve(ws));});
 const send=(ws,m)=>ws.send(JSON.stringify(m));
 const wait=async(ws,p)=>{for(let i=0;i<100;i++){const j=ws.messages.findIndex(p);if(j>=0)return ws.messages.splice(j,1)[0];await new Promise(r=>setTimeout(r,10));}throw Error('Missing message '+p);};
 try{
 for(const file of ['/','/game.js','/enhancements.js','/style.css'])assert.equal((await fetch(`http://127.0.0.1:${port}${file}`)).status,200);
 assert.equal((await fetch(`http://127.0.0.1:${port}/server.js`)).status,404);
 const h=await connect();send(h,{op:'create',name:'host',cl:0});const room=(await wait(h,m=>m.sys==='lobby')).code;
 const second=await connect();send(second,{op:'create'});const other=(await wait(second,m=>m.sys==='lobby')).code;assert.notEqual(room,other);
 const g1=await connect();send(g1,{op:'join',code:room,cl:1});await wait(g1,m=>m.sys==='lobby');
 const g2=await connect();send(g2,{op:'join',code:room,cl:2});assert.equal((await wait(g2,m=>m.sys==='lobby')).players.length,3);
 const extra=await connect();send(extra,{op:'join',code:room});assert.match((await wait(extra,m=>m.sys==='error')).message,/заполнена/);
 send(extra,{op:'join',code:'BADBAD'});assert.match((await wait(extra,m=>m.sys==='error')).message,/существует/);
 assert(!h.messages.some(m=>m.sys==='start'));
 send(g1,{op:'start'});assert.match((await wait(g1,m=>m.sys==='error')).message,/хозяин/);
 send(h,{op:'start'});for(const c of [h,g1,g2])await wait(c,m=>m.sys==='start');
 send(extra,{op:'join',code:room});assert.match((await wait(extra,m=>m.sys==='error')).message,/началась/);
 send(g1,{t:'u',k:'hp',slot:2,id:1,expected:0});const action=await wait(h,m=>m.t==='u');assert.equal(action.slot,1);
 send(g1,{t:'u',k:'hp',id:1});send(g1,{t:'p',s:77});await wait(h,m=>m.t==='p');assert(!h.messages.some(m=>m.t==='u'));
 send(h,{p:[],e:[],q:1});await wait(g1,m=>m.q===1);await wait(g2,m=>m.q===1);assert(!second.messages.some(m=>m.q===1));
 send(g2,{op:'leave'});assert.equal((await wait(h,m=>m.sys==='playerLeft')).slot,2);
 send(h,{op:'restart'});await wait(g1,m=>m.sys==='start');
 send(h,{op:'leave'});await wait(g1,m=>m.sys==='gone');
 }finally{clients.forEach(c=>c.terminate());await new Promise(r=>wss.close(r));await new Promise(r=>server.close(r));}
});
