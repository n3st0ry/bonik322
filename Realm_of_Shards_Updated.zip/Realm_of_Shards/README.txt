Realm of Shards — Tactical Update v3

Node.js LTS (20+). Откройте терминал в этой папке:
  npm install
  npm start
Откройте http://localhost:3000
Не открывайте server.js через Windows Script Host.

Без кодов: хозяин — «Создать игру по IP», гости — IP хозяина и «Подключиться по IP». Затем хозяин нажимает «Начать игру».

Новый боевой баланс, пять редкостей, четыре ветки развития, выносливость, атмосферное меню и новый HUD. Полное руководство Windows и таблицы: README.md.
Проверки и ограничения: TEST_REPORT.md. Настройки баланса: balance-config.js.
