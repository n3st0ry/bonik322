Realm of Shards — обновлённый проект

Установите Node.js LTS (20+), откройте терминал в этой папке:
  npm install
  npm start
Затем откройте http://localhost:3000
Не открывайте server.js через Windows Script Host.

Полная инструкция Windows, кооператив, управление и ручные проверки: README.md.
Фактически выполненные автоматические проверки: TEST_REPORT.md.
