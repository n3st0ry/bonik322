'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const WebSocket = require('ws');
const files = {'/':'rpg.html','/rpg.html':'rpg.html','/game.js':'game.js','/enhancements.js':'enhancements.js','/style.css':'style.css','/balance-config.js':'balance-config.js','/balance.js':'balance.js','/interface.js':'interface.js'};
function createGameServer() {
  const rooms = new Map();
  let directRoom=null;
  const server = http.createServer((req,res) => {
    let pathname;
    try { pathname = new URL(req.url,'http://localhost').pathname; } catch {res.writeHead(400);return res.end();}
    const file = files[pathname];
    if (!file || !['GET','HEAD'].includes(req.method)) {res.writeHead(404);return res.end('Not found');}
    fs.readFile(path.join(__dirname,file),(err,data)=>{
      if(err){res.writeHead(500);return res.end('Unable to load game');}
      res.writeHead(200,{'Content-Type':file.endsWith('.js')?'text/javascript; charset=utf-8':file.endsWith('.css')?'text/css; charset=utf-8':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
      res.end(req.method==='HEAD'?undefined:data);
    });
  });
  const wss = new WebSocket.Server({server,maxPayload:1024*1024});
  wss.on('error',()=>{}); // HTTP server handles listen errors (for example a busy port).
  const send=(ws,m)=>{if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify(m));};
  const broadcast=(r,m)=>r.players.forEach((_,ws)=>send(ws,m));
  const roster=r=>({sys:'lobby',code:r.code,direct:!!r.direct,status:r.status,settings:r.settings,players:[...r.players.values()].map(({slot,name,cl})=>({slot,name,cl}))});
  function leave(ws) {
    const r=ws.room;if(!r)return;ws.room=null;
    const p=r.players.get(ws);r.players.delete(ws);
    if(p.slot===0){if(directRoom===r)directRoom=null;rooms.delete(r.code);r.players.forEach((_,other)=>{other.room=null;send(other,{sys:'gone'});});}
    else {send(r.host,{sys:'playerLeft',slot:p.slot});broadcast(r,roster(r));}
  }
  wss.on('connection',ws=>{
    ws.alive=true;ws.on('pong',()=>ws.alive=true);
    ws.on('error',()=>{});ws.on('close',()=>leave(ws));
    ws.on('message',(raw,binary)=>{
      if(binary)return;let m;try{m=JSON.parse(raw.toString());}catch{return;}
      if(!m||typeof m!=='object'||Array.isArray(m))return;
      const fail=message=>send(ws,{sys:'error',message});
      if(m.op==='leave'){leave(ws);return send(ws,{sys:'left'});}
      if(['create','join','createDirect','joinDirect'].includes(m.op)){
        if(ws.room)return fail('Сначала выйдите из текущей комнаты.');
        let r;
        if(m.op==='create'||m.op==='createDirect'){
          if(m.op==='createDirect'&&directRoom)return fail('Игра по IP уже создана. Присоединитесь к ней или дождитесь выхода хозяина.');
          if(rooms.size>=500)return fail('Сервер заполнен.');
          let code;do{code=crypto.randomBytes(3).toString('hex').toUpperCase();}while(rooms.has(code));
          r={code,direct:m.op==='createDirect',status:'waiting',players:new Map(),host:ws,settings:{difficulty:'normal'}};rooms.set(code,r);if(r.direct)directRoom=r;
        }else{
          r=m.op==='joinDirect'?directRoom:rooms.get(String(m.code||'').trim().toUpperCase());
          if(!r&&m.op==='joinDirect')return fail('На этом сервере нет игры по IP. Хозяин должен нажать «Создать игру по IP».');
          if(!r)return fail('Комната не существует или закрыта.');
          if(r.status!=='waiting')return fail('Игра уже началась.');
          if(r.players.size>=3)return fail('Комната заполнена (максимум 3).');
        }
        const occupied=[...r.players.values()].map(p=>p.slot),slot=[0,1,2].find(i=>!occupied.includes(i));
        r.players.set(ws,{slot,name:String(m.name||'Искатель').replace(/[<>\x00-\x1f]/g,'').slice(0,24),cl:Number.isInteger(m.cl)&&m.cl>=0&&m.cl<5?m.cl:0,lastId:0,count:0,since:Date.now()});
        ws.room=r;send(ws,{sys:'role',r:slot===0?'host':'guest',slot});broadcast(r,roster(r));return;
      }
      const r=ws.room;if(!r)return fail('Сначала создайте комнату или введите код.');
      const p=r.players.get(ws);
      if(m.op==='profile'&&r.status==='waiting'){
        if(Number.isInteger(m.cl)&&m.cl>=0&&m.cl<5)p.cl=m.cl;
        if(typeof m.name==='string')p.name=m.name.replace(/[<>\x00-\x1f]/g,'').slice(0,24)||'Искатель';
        broadcast(r,roster(r));return;
      }
      if(m.op==='start'||m.op==='restart'){
        if(p.slot!==0)return fail('Только хозяин запускает игру.');
        if(m.op==='start'&&r.status!=='waiting')return;
        if(m.op==='restart'&&r.status!=='playing')return;
        r.status='playing';
        r.settings.difficulty=m.difficulty==='hard'?'hard':'normal';
        r.players.forEach(p=>p.lastId=0);
        broadcast(r,{...roster(r),sys:'start'});return;
      }
      if(r.status!=='playing')return;
      if(Date.now()-p.since>1000){p.count=0;p.since=Date.now();}if(++p.count>120)return;
      if(p.slot===0){
        if(m.p&&m.e&&Number.isFinite(m.q))r.players.forEach((other,target)=>{if(other.slot!==0)send(target,m);});
        else if(Number.isFinite(m.pg))r.players.forEach((other,target)=>{if(other.slot!==0)send(target,m);});
      } else {
        if(!['k','u','q','g','f','c','s','w','b','p'].includes(m.t))return;
        if(m.t!=='k'&&m.t!=='p'){
          if(!Number.isSafeInteger(m.id)||m.id<=p.lastId)return;p.lastId=m.id;
        }
        if(m.t==='k'){
          m.b=Array.from({length:8},(_,i)=>m.b?.[i]?1:0);
          m.m=Array.isArray(m.m)&&m.m.length===2&&m.m.every(Number.isFinite)?m.m.map(x=>Math.max(-10000,Math.min(10000,x))):null;
        }
        delete m.sys;delete m.op;m.slot=p.slot;send(r.host,m);
      }
    });
  });
  const heartbeat=setInterval(()=>wss.clients.forEach(ws=>{if(!ws.alive)return ws.terminate();ws.alive=false;ws.ping();}),15000);
  heartbeat.unref();server.on('close',()=>clearInterval(heartbeat));
  return {server,wss,rooms};
}
if(require.main===module){
  const {server}=createGameServer();
  server.on('error',err=>{console.error(err.code==='EADDRINUSE'?'Порт занят. Закройте другой сервер или задайте PORT.':err.message);process.exitCode=1;});
  const port=Number(process.env.PORT||3000);
  if(!Number.isInteger(port)||port<0||port>65535){console.error('Некорректный PORT');process.exitCode=1;}
  else server.listen(port,'0.0.0.0',()=>{
    const actualPort=server.address().port;
    console.log(`Realm of Shards: http://localhost:${actualPort}`);
    for(const addresses of Object.values(require('node:os').networkInterfaces()))for(const address of addresses||[])if(address.family==='IPv4'&&!address.internal)console.log(`Для друзей в вашей сети: http://${address.address}:${actualPort} · подключение по IP: ${address.address}:${actualPort}`);
    console.log('Мультиплеер → Создать игру по IP. Гости подключаются по адресу без кода. Максимум 3 игрока.');
  });
}
module.exports={createGameServer};
